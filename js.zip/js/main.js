/* mobile menu */

const mobileNavBtn = document.querySelector('.mobile-nav-btn');
const mobileNav = document.querySelector('.mobile-nav');

mobileNavBtn.addEventListener("click", openMenu);

function openMenu() {
   mobileNav.classList.toggle("mobile-nav--active");
   mobileNavBtn.classList.toggle("mobile-nav-icon-close");
}

/* video */

const videoBtn = document.querySelector('#video-btn');
const videoPicture = document.querySelector(".video__picture");
const videoWrapper = document.querySelector(".video");
const video = document.querySelector("#video-file");

videoWrapper.addEventListener('click', function (){
    videoPicture.classList.add("none");  

    if (video.paused) {
        video.play();
        videoBtn.classList.add("none");
        videoWrapper.classList.remove("video-overlay");
    } else {
        video.pause();
        videoBtn.classList.remove("none");
        videoWrapper.classList.add("video-overlay");    
    }
});

/* package card */

/* open a new page by clicking on card */

const package_card = document.querySelectorAll(".package-card");
for (i=0; i < package_card.length; i++) {
    package_card[i].addEventListener("click", 
     function() {
     window.open("./link.html");
   });
   }
   
/* click on icons in package card */

   const packageCardLink = document.querySelectorAll(".package-card__link");
   for (i=0; i < packageCardLink.length; i++) {
    packageCardLink[i].addEventListener("click", function(e){
        e.preventDefault();
        e.stopPropagation();
        this.classList.toggle("package-card__link--active");
        
    });
   }

   /* model window */
const popUp = document.querySelector(".package-card--popup");
const modelView = document.querySelectorAll(".package-card--view");
const closePopUp = document.querySelector(".package-card--row-icon");
const packagePopUp = document.querySelector(".package-card--row");

for (i=0; i < modelView.length; i++) {
    modelView[i].addEventListener("click", function(e){
        e.preventDefault();
        popUp.classList.remove("none");
        this.classList.remove("package-card__link--active");
    })
}

packagePopUp.addEventListener("click", function(){
    window.open("./link.html");
})

closePopUp.addEventListener("click", function(e){
    e.preventDefault();
    e.stopPropagation();
    popUp.classList.add("none");

});

popUp.addEventListener("click", function(e){
    e.preventDefault();
    e.stopPropagation();
    popUp.classList.add("none");

});
    
/* email validation 

function validateEmail(email) {
    var pattern = /^[\w-\.]+@[\w-]+\.[a-z]{2,4}$/i;
    return pattern.test(email);
  }

  */